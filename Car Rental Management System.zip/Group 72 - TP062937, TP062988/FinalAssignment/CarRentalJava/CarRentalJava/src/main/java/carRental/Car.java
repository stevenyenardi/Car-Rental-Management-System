package carRental;

public class Car {
    String carName;
    String carID;
    String carModel;
    String carPlate;
    String carRent;
    String carStatus;

    Car(String carID, String carName, String carModel, String carPlate, String carRent, String carStatus){
        this.carID = carID;
        this.carName = carName;
        this.carModel = carModel;
        this.carPlate = carPlate;
        this.carRent = carRent;
        this.carStatus = carStatus;
       
    }

    public void setCarID(String carID){
        this.carID = carID;
    }

    public void setCarName(String carName){
        this.carName = carName;
    }
    
    public void setCarModel(String carModel){
        this.carModel = carModel;
    }
    
    public void setCarPlateNum(String carPlate){
        this.carPlate= carPlate;
    }
    
    public void setCarRent(String carRent){
        this.carRent = carRent;
    }
    
    public void setCarStatus(String carStatus){
        this.carStatus = carStatus;
    }
        
    public String getCarID(){
        return carID;
    }
    public String getCarName(){
        return carName;
    }
    public String getCarModel(){
        return carModel;
    }
    public String getCarPlateNum (){
        return carPlate;
    }
    public String getCarRent(){
        return carRent;
    }
    public String getCarStatus(){
        return carStatus;
    }
    
    public static String carListDataConst(Car carlist){
        String carListDataConstruct = carlist.carID + ";" + carlist.carName + ";" + carlist.carModel + ";" + carlist.carPlate + ";" + carlist.carRent + ";"  + carlist.carStatus +";" + carlist.carStatus  + ";";
        return carListDataConstruct;
    }
}
