/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carRental;

import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;

/**
 *
 * @author Republic Of Gamers
 */
public class DataStoring {
    
    public static void writeData(String DataConst) throws IOException{
        try{
            FileWriter writeToFile = new FileWriter("ClientData.txt", true);
            BufferedWriter bufferedwriter = new BufferedWriter(writeToFile);
            bufferedwriter.write(DataConst + "\n");
            bufferedwriter.flush();
            bufferedwriter.close();
            System.out.println("Successfully wrote to the file.");
            System.out.println(DataConst);
        }
        catch(Exception e){
            System.out.println("Data not found");
        }
    }
    
}
