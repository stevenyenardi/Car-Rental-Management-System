/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carRental;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Republic Of Gamers
 */
public class DataReading {
    public static String[] readData(String username, String password)throws IOException{
        FileReader readCredentials;
        BufferedReader br = null;
        
        try{
            readCredentials = new FileReader("ClientData.txt");
            br = new BufferedReader(readCredentials);
        }
        catch(Exception e){
            System.out.println("Data not found");
        }
        String credentials = br.readLine();
        while (credentials != null){
            String[] detail = credentials.split(";");
            
            if(username.equals(detail[0]) && password.equals(detail[1])){
                return detail;
            }
            credentials = br.readLine();
        }
        return null;
    }
    
}
