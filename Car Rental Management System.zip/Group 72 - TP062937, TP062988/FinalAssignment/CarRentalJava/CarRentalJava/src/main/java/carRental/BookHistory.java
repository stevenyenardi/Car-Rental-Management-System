/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carRental;

/**
 *
 * @author Republic Of Gamers
 */
public class BookHistory extends Car {
    String startDate;
    String returnDate;
    String custName;
    String totalFee;
    String paymentMethod;
    
    public BookHistory(String carID, String carName, String carModel, String carPlate, String carRent, String carStatus, String startDate, String returnDate, String custName, String totalFee, String paymentMethod) {
        super(carID, carName, carModel, carPlate, carRent, carStatus);
        this.startDate = startDate;
        this.returnDate = returnDate;
        this.custName = custName;
        this.totalFee = totalFee;
        this.paymentMethod = paymentMethod;
    }
    
    public void setStartDate (String startDate){
        this.startDate = startDate;
    }
    public void setReturnDate (String returnDate){
        this.returnDate = returnDate;
    }
    public void setCustName (String custName){
        this.custName = custName;
    }
    public void setTotalFee (String totalFee){
        this.totalFee = totalFee;
    }    
    public void setPaymentMethod(String paymentMethod){
        this.paymentMethod = paymentMethod;
    }    
    public String getStartDate(){
        return startDate;
    }
    public String getReturnDate(){
        return returnDate;
    }
    public String getCustName(){
        return custName;
    }
    public String getTotalFee(){
        return totalFee;    
    }
    public String getPaymentMethod(){
        return paymentMethod;
    }
    
    public static String carDataConst(BookHistory car){
        String carDataConstruct = car.carID + ";" + car.custName + ";" + car.carName + ";" + car.carPlate + ";" + car.startDate + ";"  + car.returnDate +";" + car.totalFee +";" + car.paymentMethod + ";" + car.carStatus  + ";";
        return carDataConstruct;
    }
}
