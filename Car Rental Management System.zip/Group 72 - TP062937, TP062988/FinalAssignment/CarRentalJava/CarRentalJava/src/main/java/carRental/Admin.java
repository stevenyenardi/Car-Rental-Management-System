/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package carRental;

/**
 *
 * @author Republic Of Gamers
 */
public class Admin extends User
{
    public Admin(String username, String password, String name, String phoneNum, String email, String DOB){
        super(username, password, name, phoneNum, email, DOB);
    }
    
    public static String DataConstructAdm(User adm){
    String DataConstAdmin = adm.getUsername() + ";" + adm.getPassword() + ";" ;
    return DataConstAdmin;
}
    
}