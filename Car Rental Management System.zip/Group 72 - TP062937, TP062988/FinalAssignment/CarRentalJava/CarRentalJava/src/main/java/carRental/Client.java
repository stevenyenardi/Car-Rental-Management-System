/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carRental;

/**
 *
 * @author Republic Of Gamers
 */
public class Client extends User {


    public Client(String username, String password, String name, String phoneNum, String email, String DOB){
        super(username, password, name, phoneNum, email, DOB);
    }
    
    public static String DataConstruct(User people){
    String DataConst = people.getUsername() + ";" + people.getPassword() + ";" + people.name + ";" + people.phoneNum + ";" + people.email + ";" + people.DOB + ";";
    return DataConst;
    }
}