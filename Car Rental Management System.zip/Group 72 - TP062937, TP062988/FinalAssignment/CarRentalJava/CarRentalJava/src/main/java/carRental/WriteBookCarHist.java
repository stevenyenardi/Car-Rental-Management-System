/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carRental;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Republic Of Gamers
 */
public class WriteBookCarHist {
    public static void writeBookingData(String carDataConst) throws IOException{
        try{
            FileWriter writeCarToFile = new FileWriter("BookingHistory.txt", true);
            BufferedWriter bufferedwriter = new BufferedWriter(writeCarToFile);
            bufferedwriter.write(carDataConst + "\n");
            bufferedwriter.flush();
            bufferedwriter.close();
            System.out.println("Successfully wrote to the file.");
            System.out.println(carDataConst);
        }
        catch(Exception e){
            System.out.println("Data not found");
        }
    }
    
}

