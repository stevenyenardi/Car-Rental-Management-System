/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carRental;

import java.io.IOException;

/**
 *
 * @author Republic Of Gamers
 */
public class User {
    String name;
    String phoneNum;
    String email;
    String DOB;
    private String username;
    private String password;
    

    User(String username, String password, String name, String phoneNum, String email, String DOB){
        this.username = username;
        this.password = password;
        this.name = name;
        this.phoneNum = phoneNum;
        this.email = email;
        this.DOB = DOB;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setPhoneNum(String phoneNum){
        this.phoneNum = phoneNum;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setDOB (String DOB){
        this.DOB = DOB;
    }
    public void setPassword (String password){
        this.password = password;
    }
    public void setusername (String username){
        this.username = username;
    }
    public String getName(){
        return name;
    }
    public String getPhoneNum(){
        return phoneNum;
    }
    public String getEmail(){
        return email;
    }
    public String getDOB(){
        return DOB;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }

    void readData(String username, String password) {
         
    }
    
    //public boolean login() throws IOException{
    //    return DataReading.readData(this.username, this.password);
    //}
}
